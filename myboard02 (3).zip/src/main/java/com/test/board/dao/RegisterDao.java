package com.test.board.dao;

import com.test.board.login.MemberVO;

public interface RegisterDao {
	public abstract void register(MemberVO memberVO);
}
