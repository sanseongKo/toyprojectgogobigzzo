package com.test.board.dao;

public interface LoginDao {
	
}
